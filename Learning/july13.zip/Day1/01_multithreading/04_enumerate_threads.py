from time import sleep


def foo(x):
    from threading import current_thread
    th = current_thread()
    for i in range(x):
        print("foo[{}]: counting {}".format(th.name, i))
        sleep(1)


if __name__ == '__main__':
    import threading

    for i in range(10):
        threading.Thread(target=foo, args=(10,)).start()

    for t in threading.enumerate():
        print("Thread {} running".format(t.name))

    for t in threading.enumerate():
        #if t.name == 'MainThread':
        #    continue
        if t is threading.main_thread():
            continue

        t.join()
        print("Thread {} completed.".format(t.name))
