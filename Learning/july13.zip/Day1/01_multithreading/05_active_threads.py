from threading import Thread, current_thread
from time import sleep


def counter(c, interval):
    th = current_thread()

    for i in range(c):
        print("{}: counting {}".format(th.name, i))
        sleep(interval)


if __name__ == '__main__':
    t1 = Thread(target=counter, args=(5, 1))
    t1.start()

    t2 = Thread(target=counter, args=(8, 1), daemon=True)
    #t2.daemon = True
    t2.start()

    t1.join()
    print("{} completed...".format(t1.name))
    print("end of main thread...")
