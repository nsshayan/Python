from __future__ import print_function

import pyximport
pyximport.install()
from thread_workers import worker

from threading import Thread
from performance import profile_time, print_log

@profile_time
def start_workers():
    pool = { }
    for i in range(16):
        pool[i] = Thread(target=worker, args=(i,))
        pool[i].start()
    print("Created 16 workers...\n", end="")

    for i in range(16):
        pool[i].join()
    print("All workers complete...\n", end="")

start_workers()

print_log()

