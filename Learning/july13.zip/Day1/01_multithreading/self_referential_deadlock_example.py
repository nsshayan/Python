from threading import Thread, Lock

class ScoreBoard:
    def __init__(self):
        self.scores = {}
        self.score_lock = Lock()

    def get_score(self, player):
        with self.score_lock:
            score = self.scores.get(player)
        return score

    def set_score(self, player, score):
        with self.score_lock:
            self.scores[player] = score

    def bad_add_score(self, player, score):
        with self.score_lock:
            old_score = self.get_score(player)
            self.set_score(player, old_score + score)

    def add_score(self, player, score):
        with self.score_lock:
            self.scores[player] += score
