from threading import Thread

class MyTimer(Thread):
    def __init__(self, interval, fn, *args, **kwargs):
        Thread.__init__(self, *args, **kwargs)
        self.fn = fn
        self.interval = interval
        
    def run(self):
        from time import sleep
        sleep(self.interval)
        self.fn()
    
def timeout_fn():
    print("**** Timeout occurred")
    exit(0)
    
if __name__ == '__main__':
    m = MyTimer(10, timeout_fn)
    m.daemon = True
    m.start()
    name = input("Enter your name: ")
    print("Hello", name)
    
        