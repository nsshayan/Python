from __future__ import print_function

from time import sleep
from threading import Thread
from itertools import count


def foo():
    for i in count():
        print("In foo: counting {}".format(i))


def bar():
    for i in count():
        print("In bar: counting {}".format(i))


if __name__ == '__main__':
    f = Thread(target=foo)
    b = Thread(target=bar)

    f.daemon = True
    b.daemon = True

    f.start()
    b.start()
    print("main: created two threads...")

    for i in range(7):
        print("main: counting {}".format(i))
        print("main: counting", i)
        sleep(1)

    # b.join()
    #print("bar completed!")

    # f.join()
    #print("foo completed!")

    print("main exiting...")
