from threading import current_thread


th = current_thread()
print(th.name, th.is_alive(), th.daemon) 