from time import sleep
from threading import Thread, current_thread

def foo(c, s):
    th = current_thread()
    for i in range(c):
        print("In {}: counting {}".format(th.name, i))
        sleep(s)

if __name__ == '__main__':
    m = current_thread()
    f = Thread(target=foo, name="Foo-Thread", args=(10, 1))
    b = Thread(target=foo, name="Bar-Thread", args=(5, 1))

    f.start()
    b.start()
    print("{}: created two threads...".format(m.name))

    foo(7, 1)

    b.join()
    print("{} completed!".format(b.name))

    f.join()
    print("{} completed!".format(f.name))

    print("{} exiting...".format(m.name))
