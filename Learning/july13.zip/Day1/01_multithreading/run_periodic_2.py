from threading import Thread, Event

class RunPeriodic(Thread):
    def __init__(self, interval, fn, *args, **kwargs):
        Thread.__init__(self, *args, **kwargs)
        self.interval = interval
        self.fn = fn
        #self.quit = False
        self.quit = Event()

    def run(self):
        from time import sleep

        #while not self.quit:
        while not self.quit.is_set():
            self.fn()
            #sleep(self.interval)
            self.quit.wait(self.interval)

    def stop(self):
        self.quit.set()
