from threading import Thread, current_thread
from time import sleep


def counter():
    thread_name = current_thread().name
    for i in range(10):
        print(f"{thread_name}: counting {i}")
        sleep(0.5)


if __name__ == '__main__':
    t1 = Thread(target=counter)
    t2 = Thread(target=counter)
    t1.start()
    t2.start()
