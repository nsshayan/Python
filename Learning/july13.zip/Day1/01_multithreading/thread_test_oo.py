from threading import Thread, current_thread
from time import sleep


class CounterThread(Thread):

    def __init__(self, times, *args, **kwargs):
        Thread.__init__(self, *args, **kwargs)
        #super(CounterThread, self).__init__(*args, **kwargs)
        self.__times = times

    def run(self):
        for i in range(self.__times):
            print(f"{self.name}: counting", i)
            sleep(1)


def counter():
    thread = current_thread()
    for i in range(10):
        print(f"{thread.name}: counting: ", i)
        sleep(1)


if __name__ == '__main__':
    a = CounterThread(10, name="foo")
    b = CounterThread(20, name="bar")
    c = Thread(target=counter, name="counter")
    a.start()
    b.start()
    c.start()
