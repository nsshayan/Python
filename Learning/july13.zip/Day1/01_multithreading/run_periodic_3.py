from threading import Thread, Event

class RunPeriodic(Thread):
    def __init__(self, interval, fn, *args, **kwargs):
        Thread.__init__(self, *args, **kwargs)
        self.__interval = interval
        self.__fn = fn
        self.__quit = Event()

    def run(self):
        while not self.__quit.wait(self.__interval):
            self.__fn()

    def stop(self):
        self.__quit.set()
