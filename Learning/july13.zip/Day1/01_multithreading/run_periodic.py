from threading import Thread, Event


class RunPeriodic(Thread):
    def __init__(self, interval, function, args=(), kwargs={}, *a, **k):
        Thread.__init__(self, *a, **k)
        self.__interval = interval
        self.__fn = function
        self.__fn_args = args
        self.__fn_kwargs = kwargs
        self.__cancel = False

    def run(self):
        from time import sleep
        while not self.__cancel:
            self.__fn(*self.__fn_args, **self.__fn_kwargs)
            sleep(self.__interval)

    def stop(self):
        self.__cancel = True
