from threading import Thread
from time import sleep
import threading


def testfn():
    th = threading.current_thread()
    print("testfn called from", th.name)
    sleep(10)
    print("testfn exiting...")


if __name__ == '__main__':
    a = Thread(target=testfn, name="Monitor")
    b = Thread(target=testfn, name="Heartbeat")
    print("Created a =", a)
    print("Created b =", b)
    a.start()
    b.start()
    testfn()
