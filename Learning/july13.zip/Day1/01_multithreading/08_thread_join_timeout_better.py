from __future__ import print_function
from time import sleep
from threading import Thread, current_thread
from random import randint
from collections import deque

def fn(count):
    th = current_thread()
    for i in range(count):
        print("In {} counting {}/{}".format(th.name, i, count))
        sleep(0.5)

if __name__ == '__main__':
    threads = deque()
    for i in range(1, 6):
        t = Thread(target=fn, args=(randint(3, 25),))
        threads.append(t)
        t.start()

    while threads:
        t = threads[0]
        t.join(0.5)
        if not t.is_alive():
            t.popleft()
        else:
            t.rotate(-1)

    print("main complete")
