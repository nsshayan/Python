from threading import Thread, current_thread
from time import sleep


class CounterThread(Thread):

    def run(self):
        #thread_name = current_thread().name
        for i in range(10):
            print(f"{self.name}: counting {i}")
            sleep(0.5)


if __name__ == '__main__':
    t1 = CounterThread()
    t2 = CounterThread()
    t1.start()
    t2.start()
