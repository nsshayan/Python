from time import sleep
from threading import Thread, current_thread


def foo(x, interval):
    th = current_thread()
    for i in range(x):
        if hasattr(th, "cancel"):
            break
        print("foo[{}]: counting {}".format(th.name, i))
        sleep(interval)


if __name__ == '__main__':

    t1 = Thread(target=foo, args=(15, 10))

    t1.start()

    sleep(5)
    t1.cancel = True
    t1.join()
