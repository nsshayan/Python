from threading import Thread, current_thread
from time import sleep

def testfn(x):
    for i in range(x):
        tname = current_thread().name
        print(f"{tname}: counting {i}")
        sleep(1)

if __name__ == '__main__':
    t1 = Thread(target=testfn, args=(10,))
    t1.start()
    testfn(5)
    t1.join(timeout=2)
    if t1.is_alive():
        print(t1, "is still running")

    t1.join(timeout=5)
    if t1.is_alive():
        print(t1, "is still running")
    else:
        print(t1, "completed...")
    print("main complete.")
