from threading import Timer

def timeout_fn():
    print("**** Timeout occurred")
    exit(0)
    
if __name__ == '__main__':
    m = Timer(10, timeout_fn)
    m.daemon = True
    m.start()
    name = input("Enter your name: ")
    print("Hello", name)
    
        