from threading import Thread
from time import sleep

class CounterThread(Thread):

    def __init__(self, name, count):
        super().__init__(name=name)
        self.count = count

    def run(self):
        for i in range(self.count):
            print(f"{self.name}: counting {i}")
            sleep(0.5)

if __name__ == '__main__':
    t1 = CounterThread(name="counter-1", count=5)
    t2 = CounterThread(name="counter-2", count=7)
    t1.start()
    t2.start()
