from time import sleep
from threading import Thread, current_thread, Event
from itertools import count

cancel = Event()


def foo():
    th = current_thread()
    for i in count():
        if cancel.is_set():
            break
        print("foo[{}]: counting {}".format(th.name, i))


if __name__ == '__main__':

    t1 = Thread(target=foo)

    t1.start()

    sleep(5)
    cancel.set()
    t1.join()
