from threading import Thread


class RunPeriodic:
    def __init__(self, interval, fn, *args, **kwargs):
        self.thread = Thread(target=self.run)
        self.args = args
        self.kwargs = kwargs
        self.interval = interval
        self.cancel = False
        self.fn = fn

    def run(self):
        from time import sleep
        while not self.cancel:
            self.fn(*self.args, **self.kwargs)
            sleep(self.interval)

    def stop(self):
        self.cancel = True

    def __getattr__(self, attr):
        return getattr(self.thread, attr)
