from threading import Thread, current_thread
from time import sleep


def counter(c):
    name = current_thread().name
    for i in range(c):
        print(f"{name}: counting {i}")
        sleep(0.5)


def join_all(*threads):
    threads = list(threads)
    while threads:
        for t in threads:
            t.join(0.1)
            if not t.is_alive():
                print(f"{t.name} exited")
                threads.remove(t)


def join_all_deque(*args):
    from collections import deque
    threads = deque(args)
    while threads:
        t = threads[0]
        t.join(0.1)
        if not t.is_alive():
            t.popleft()
        else:
            t.rotate(-1)


if __name__ == '__main__':
    a = Thread(target=counter, args=(10,))
    b = Thread(target=counter, args=(5,))

    a.start()
    b.start()

    join_all(a, b)

    # a.join()
    #print("a completed...")
    # b.join()
    #print("b completed...")

    print("main exited.")
