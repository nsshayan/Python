from __future__ import print_function

from time import sleep
from threading import Thread


def foo(c, s):
    for i in range(c):
        print("In foo: counting {}".format(i))
        print("In foo: counting", i)
        #sleep(s)


def bar(c, s):
    for i in range(c):
        print("In bar: counting {}".format(i))
        print("In bar: counting", i)
        #sleep(s)


if __name__ == '__main__':
    f = Thread(target=foo, args=(15000, 0.5))
    b = Thread(target=bar, kwargs={"c": 10000, "s": 0.5})

    print("main: created two threads...")

    f.start()
    b.start()

    for i in range(5000):
        print("main: counting {}".format(i))
        print("main: counting", i)
        #sleep(0.5)

    print("main exiting...")
