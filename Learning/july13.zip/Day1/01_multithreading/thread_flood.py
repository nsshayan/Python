from itertools import count

from gevent import monkey
monkey.patch_all()

from threading import Thread, current_thread
from time import sleep

def foo():
    t = current_thread()
    print(f"foo running on {t.name}")
    sleep(60)

if __name__ == '__main__':
    for i in count():
        Thread(target=foo).start()
