#from threading import Thread, current_thread
from multiprocessing import Process as Thread, current_process as current_thread

from time import sleep


def foo():
    name = current_thread().name
    for i in range(20):
        print("In {}: Counting {}".format(name, i))
        sleep(1)


if __name__ == '__main__':
    workers = []
    for i in range(16):
        w = Thread(target=foo)
        workers.append(w)
        w.start()
