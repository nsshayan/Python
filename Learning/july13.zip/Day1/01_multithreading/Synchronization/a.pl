$a = "10 apples";
$b = "20 oranges";
$c = $a + $b;
print "c = $c\n";

