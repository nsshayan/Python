from threading import Thread
from time import sleep

class Counter(Thread):

    def __init__(self, times, interval):
        # Thread.__init__(self)
        super().__init__()

        self.times = times
        self.interval = interval

    def run(self):
        for i in range(self.times):
            print(f"{self.name} counting {i}")
            sleep(self.interval)

c = Counter(times=10, interval=0.5)
c.start()
c.join()
