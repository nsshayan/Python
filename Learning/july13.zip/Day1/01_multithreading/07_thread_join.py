from __future__ import print_function
from time import sleep
from threading import Thread, current_thread
from random import randint

def fn(count):
    th = current_thread()
    for i in range(count):
        print("In {} counting {}/{}".format(th.name, i, count))
        sleep(0.5)

if __name__ == '__main__':
    threads = []
    for i in range(1, 6):
        t = Thread(target=fn, args=(randint(5, 25),))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()
        print("{} complete.".format(t.name))
 
    print("main complete")
