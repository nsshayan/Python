from threading import Thread, current_thread
import threading

from time import sleep

def foo():
    th_name = current_thread().name    
    print(f"Name of current thread is {th_name}")
    print("Active threads: ", threading.active_count())

    for t in threading.enumerate():
        print(t)    

    sleep(5)

if __name__ == '__main__':
    a = Thread(target=foo, name="Test_thread")
    b = Thread(target=foo, name="monitor-thread")
    c = Thread(target=foo, name="dsfsdsdf")

    a.start()
    b.start()
    c.start()
    foo()

