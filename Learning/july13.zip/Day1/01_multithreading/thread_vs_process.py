#from threading import Thread
from multiprocessing import Process as Thread


def foo():
    from time import sleep
    sleep(60)


if __name__ == '__main__':
    for i in range(16):
        Thread(target=foo).start()
