from threading import Thread
from time import sleep


class CounterThread(Thread):

    def __init__(self, count, interval, name):
        Thread.__init__(self, name=name)
        #super(self, CounterThread).__init__()
        self.count, self.interval = count, interval

    def run(self):
        for i in range(self.count):
            #print("{}: counting {}".format(self.name, i))
            print(f"{self.name}: counting {i}")
            sleep(self.interval)


if __name__ == '__main__':
    a = CounterThread(10, 1, "thread-a")
    b = CounterThread(5, 1, "test-thread")
    c = CounterThread(7, 1, "another-thread")

    a.start()
    b.start()
    c.start()
