from threading import Thread, current_thread
from time import sleep


def foo(x):
    t = current_thread()
    for i in range(x):
        #print("{}: counting {}".format(t.name, i))
        print(f"{t.name}: counting {i}")
        sleep(1)


def monitor(interval):
    t = current_thread()
    from itertools import count
    for i in count():
        print("{}: monitoring {}".format(t.name, i))
        sleep(interval)


if __name__ == '__main__':
    a = Thread(target=foo, args=(5,))
    b = Thread(target=foo, args=(15,))
    c = Thread(target=monitor,
               name = "MonitorThread",
               args = (0.5,),
               daemon = True)



    a.start()
    b.start()

    #c.daemon = True
    c.start()

    foo(7)
