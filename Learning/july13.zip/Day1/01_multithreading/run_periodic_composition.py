from threading import Thread, Event


class RunPeriodic:
    def __init__(self, interval, fn, *args, **kwargs):
        self.thread = Thread(target=self.run)
        self.args = args
        self.kwargs = kwargs
        self.interval = interval
        self.cancel = Event()
        self.fn = fn

    def start(self):
        self.thread.start()

    def run(self):
        while not self.cancel.is_set():
            self.fn(*self.args, **self.kwargs)
            self.cancel.wait(self.interval)

    def stop(self):
        self.cancel.set()

    def join(self):
        self.thread.join()
