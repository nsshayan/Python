use std::time::Instant;
use std::thread;

fn start_workers() {
    let mut pool = vec![]; 

    for w in 0..15 {
        pool.push(thread::spawn(move || {
            let mut y :u64 = 0;
            println!("Starting worker {}", w);
            for i in 0..1000 {
                for j in 0..10000 {
                    y += i * j;
                }
            }
            println!("Worker {} complete: y = {}", w, y);
        }));
    }
    println!("Created 16 workers...");
    for worker in pool {
        let _ = worker.join();
    }
    println!("All workers complete...");

}

fn main() {
    let now = Instant::now(); 
    start_workers();
    let duration = now.elapsed().as_secs() as f64 + now.elapsed().subsec_nanos() as f64 * 1e-9;
    println!("start_workers: {} seconds", duration);
}

