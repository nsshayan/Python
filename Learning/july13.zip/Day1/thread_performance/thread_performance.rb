def start_workers
    pool = []
    10.times do |w|
        pool << Thread.new do 
            y = 0
            puts "Starting worker: #{w}"
            1000.times do |i|
                10000.times do |j|
                    y += i * j
                end
            end
            puts "Worker #{w} complete: y = #{y}"
        end
    end
    puts "Created 16 workers..."
    pool.each {|thread| thread.join }
    puts "All workers complete..."
end

start = Time.now.to_f
start_workers
duration = Time.now.to_f - start

puts "start_workers: #{duration} seconds"

