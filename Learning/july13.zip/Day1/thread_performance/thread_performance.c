#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <stdlib.h>
#include <time.h>
#include <stdarg.h>

#define COUNT 10000000L /* 10 million */

int rprintf(const char *fmt, ...);

int rprintf(const char *fmt, ...)
{
    va_list args;
    char buf[512];
    int rc;

    va_start( args, fmt );

    rc = vsnprintf(buf, sizeof(buf), fmt, args);
    va_end (args);

    if (rc > 0 && rc < sizeof(buf)) 
        write(1, buf, rc);

    return rc;
}

double diff_time(struct timespec start, struct timespec end)
{
    struct timespec interval;
	double duration;

    if ((end.tv_nsec - start.tv_nsec) < 0) {
        interval.tv_sec = end.tv_sec - start.tv_sec - 1;
        interval.tv_nsec = 1000000000 + end.tv_nsec - start.tv_nsec;
    } else {
        interval.tv_sec = end.tv_sec - start.tv_sec;
        interval.tv_nsec = end.tv_nsec - start.tv_nsec;
    }
    duration = interval.tv_sec + interval.tv_nsec / 1000000000.0;
    return duration;
}


typedef struct {
    unsigned long value;
} integer_t;

integer_t *alloc_integer(unsigned long v)
{
    integer_t *i = (integer_t *)malloc(sizeof(integer_t));
    i->value = v;
    return i;
}

void free_integer(integer_t *i)
{
    free(i);
}

void* worker(void *arg)
{
    integer_t *n;
    unsigned long i = COUNT;
    unsigned long *w = (unsigned long *)arg;

    rprintf("Starting worker: %lu\n", *w);
    while (i > 0) {
        n = alloc_integer(i);
        i--;
        free_integer(n);
    }
    rprintf("Worker %lu complete.\n", *w);

    return NULL;
}

void start_workers(void)
{
    struct timespec start, end;

    pthread_t pool[16];
    int i;
    void *ret;

    clock_gettime(CLOCK_REALTIME, &start);
    for (i=0; i<24; i++) {
        pthread_create(&pool[i], NULL, worker, alloc_integer(i+1));
    }
    rprintf("Created 24 workers...\n");

    for (i=0; i<24; i++) {
        pthread_join(pool[i], &ret);
    }

    rprintf("All workers complete.\n");
    clock_gettime(CLOCK_REALTIME, &end);
	rprintf("start_workers : %f seconds.\n", diff_time(start, end));

}

int main()
{
    start_workers();
    return 0;
}

