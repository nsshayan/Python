package main

import (
    "fmt"
    "time"
    "sync"
)

func start_workers() {
    var wg sync.WaitGroup
    for r := 1; r <= 24; r++ {
        wg.Add(1)

        go func(w int) {
            var n = 10000000
            defer wg.Done()
            fmt.Printf("Starting worker: %d\n", w)
            for n > 0 {
                n -= 1
            }
            fmt.Printf("Worker %d complete\n", w)
        }(r)
    }
    fmt.Printf("Created 24 workers...\n")
    wg.Wait()
    fmt.Printf("All workers complete...\n")
}

func main() {
    start := time.Now().UnixNano()
    start_workers()
    duration := float64(time.Now().UnixNano() - start) / 1000000000.0
    fmt.Printf("start_workers: %f seconds\n", duration)

}
