"""
A simple python module that provides
function decorator to profile time taken
by any python function
"""
from __future__ import print_function
from sys import version_info as version

log = { }

def profile_time(f):
    def wrapper(*args, **kwargs):
        from time import time
        start = time()
        r = f(*args, **kwargs)
        duration = time() - start
        if version.major == 2:
            log[f.func_name] = duration
        else:
            log[f.__qualname__] = duration
        return r
    return wrapper

def print_log():
    for k, v in log.items(): 
        print(k, ": ", v, "seconds")


