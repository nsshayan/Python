from __future__ import print_function

COUNT = 10000000

from threading import Thread

from performance import profile_time, print_log
from numba import jit, void, int32


@jit(void(int32))
def worker(w):
    n = 10000000

    print("Starting worker: {}\n".format(w), end="")
    while n > 0:
        n -= 1
    print("Worker {} complete.\n".format(w), end="")

@profile_time
def start_workers():
    pool = { }
    for i in range(8):
        pool[i] = Thread(target=worker, args=(i,))
        pool[i].start()
    print("Created 8 workers...\n", end="")

    for i in range(8):
        pool[i].join()
    print("All workers complete...\n", end="")

start_workers()

print_log()

