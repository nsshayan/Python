object ThreadPerformance extends App {

  def startWorkers() = {
    var pool:Array[Thread] = new Array[Thread](16)
    
    for (i <- 0 to 15) {
      pool(i) = new Thread(new Runnable {
          def run() {
            var n:Long = 10000000L
            val w = Thread.currentThread().getName()

            println("Starting worker: " + w)
            while (n > 0) {
              n -= 1
            }
            print("Worker " + w + " complete\n")
            
          }
        })
        pool(i).start()
      }
      println("Created 16 workers...")
      for (w <- pool)
        w.join()
      
      println("All workers complete...")
  }

  var start:Long = System.currentTimeMillis()
  startWorkers()
  var duration:Long = System.currentTimeMillis() - start
  printf("startWorkers: %f seconds.\n", (duration / 1000.0))
}

