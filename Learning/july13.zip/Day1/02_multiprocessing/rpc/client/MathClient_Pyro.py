import Pyro4

uri = input("Enter uri: ")

maths = Pyro4.Proxy(uri)

print(maths.add(10, 20))
print(maths.mul(10, 20))

