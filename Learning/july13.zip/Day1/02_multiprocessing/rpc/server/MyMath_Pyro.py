import Pyro4
from time import sleep


@Pyro4.expose
class MathsClass:
    def add(self, x, y):
        print("add method called.")
        sleep(5)
        return x + y

    def mul(self, x, y):
        print("mul method called.")
        return x * y


if __name__ == '__main__':
    daemon = Pyro4.Daemon()
    uri = daemon.register(MathsClass)
    print("Maths available at {}".format(uri))
    daemon.requestLoop()
