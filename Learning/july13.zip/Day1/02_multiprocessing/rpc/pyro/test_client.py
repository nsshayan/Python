from time import sleep

def square(x):
    sleep(2)
    return x*x

def add(x, y):
    sleep(3)
    return x + y

if __name__ == '__main__':
    square_tests = [
        dict(args=(2,), returns=4),
        dict(args=(3.0,), returns=9.0),
        dict(kwargs={"x": 4}, returns=16),
        dict(args=("Hello",), raises=TypeError("parameter must be number"))
    ]

    add_tests = [
        dict(args=(1, 2), returns=3),
        dict(args=(10, 20, 30), returns=60),
        dict(args=("John", "Doe"),
             raises=TypeError("parameters must be numbers"))
    ]

    import Pyro4
    test_manager = Pyro4.Proxy("PYRONAME:test.manager")
    job_id = test_manager.submit(square, square_tests)
    print("square() submitted: job-id:", job_id)

    job_id = test_manager.submit(add, add_tests)
    print("add() submitted: job-id:", job_id)
