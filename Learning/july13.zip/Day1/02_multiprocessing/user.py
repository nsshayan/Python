class User:
    def __init__(self):
        self.testdata = 100

