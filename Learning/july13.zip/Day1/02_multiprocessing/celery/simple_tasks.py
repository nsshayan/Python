from celery import Celery

app = Celery('simple_tasks',
             backend='rpc://',
             broker='redis://localhost/')
# broker='pyamqp://guest@localhost//')

from time import sleep

count = 100000000

@app.task
def add(x, y):
    print("add called...")
    for i in range(count): pass

    return x + y


