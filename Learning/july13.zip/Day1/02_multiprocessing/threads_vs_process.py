#from threading import Thread as Task, Event
from multiprocessing import Process as Task, Event
from multiprocessing import Manager

#a = [0] * 5

m = Manager()
a = m.list([0] * 5)

d = m.dict(name="Sam", role="admin")

#print(a, type(a))

fill_event = Event()
update_event = Event()

def foo():
    print("In foo: a =", a)
    for i in range(5):
        a[i] = i
    fill_event.set()

def bar():
    fill_event.wait()
    print("In bar: a =", a)
    for i, v in enumerate(a):
        a[i] = v*v
    update_event.set()

if __name__ == '__main__':
    t1 = Task(target=foo)
    t2 = Task(target=bar)
    t1.start()
    t2.start()

    update_event.wait()
    print("In main: a =", a)
