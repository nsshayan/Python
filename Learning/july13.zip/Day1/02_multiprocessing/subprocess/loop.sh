#!/bin/bash
i=0
while true
do
    echo "Counting $i"
    #sleep 1
    i=$((i+1))
done

