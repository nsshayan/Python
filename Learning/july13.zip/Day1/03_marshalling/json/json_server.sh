#!/bin/sh
json-server --watch db.json
