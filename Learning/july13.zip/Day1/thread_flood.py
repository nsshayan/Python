from gevent import monkey
monkey.patch_all()

from threading import Thread
from time import sleep
import itertools

def testfn(i):
    print(f"Thread {i}: spawned")
    sleep(60)

if __name__ == '__main__':
    for c in itertools.count():
        Thread(target=testfn, args=(c,)).start()
