import gevent
# pip install gevent

def foo():
    for i in range(10):
        print("In foo: counting ".format(i))
        gevent.sleep(0)
        #sleep(1)


def bar():
    for i in range(7):
        print("In bar: counting ".format(i))
        gevent.sleep(0)
        #sleep(1)


if __name__ == '__main__':
    f = gevent.spawn(foo)
    b = gevent.spawn(bar)

    for i in range(3):
        print("In main: counting ".format(i))
        #sleep(1)
        gevent.sleep(0)

    gevent.joinall([f, b])
