from threading import Thread
from time import sleep

def foo(x):
    for i in range(x):
        sleep(1)
        print("foo: counting {}".format(i))
        if i == 3:
            while True:
                print(".", end="")

def bar(n):
    for i in range(n):
        sleep(1)
        print("bar: counting {}".format(i))

if __name__ == '__main__':
    #t1 = Thread(target=foo, args=(10,))
    t1 = Thread(target=foo, kwargs={"x": 10})
    
    t2 = Thread(target=bar, args=(20,))

    t1.start()
    t2.start()

    for i in range(5):
        print("main: counting", i)
        sleep(1)

    print("main complete...")
