"""
Implement the 'Tasklets' class that allows adding generators into
a runqueue and schedule them.

Under the '__main__' namespace, the following is a sample use-case.
Running this program should generate result as below:
    foo: counting 0
    bar: counting 0
    foo: counting 1
    bar: counting 1
    foo: counting 2
    bar: counting 2
    foo: counting 3
    bar: counting 3
    foo: counting 4
    bar: counting 4
    foo: counting 5
    foo: counting 6
    foo: counting 7
    foo: counting 8
    foo: counting 9
"""


class Tasklets:

    def __init__(self):
        from collections import deque
        self.runqueue = deque()

    def add(self, fn, *args, **kwargs):
        self.runqueue.append(fn(*args, **kwargs))

    def run(self):
        while self.runqueue:
            task = self.runqueue[0]
            try:
                next(task)
            except StopIteration:
                self.runqueue.popleft()
            else:
                self.runqueue.rotate()


if __name__ == '__main__':

    def foo(x):
        for i in range(x):
            yield
            print("foo: counting {}".format(i))

    def bar(n):
        for i in range(n):
            yield
            print("bar: counting {}".format(i))

    tasklets = Tasklets()
    tasklets.add(foo, 10)
    tasklets.add(bar, 6)
    tasklets.run()  # Schedule tasklets (generator functions) added into the runqueue
