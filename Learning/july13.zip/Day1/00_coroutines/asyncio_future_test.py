import asyncio
from time import sleep


async def testfn(result):
    print("testfn started, sleeping for 5 seconds...")
    await asyncio.sleep(5)
    print("testfn resumed after 5 seconds...")
    result.set_result('testfn is done!')

if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    result_value = asyncio.Future()
    asyncio.ensure_future(testfn(result_value))
    print("__main__: testfn() launched...")

    for i in range(3):
        print("__main__: counting", i)
        asyncio.sleep(1)

    print("__main__: waiting for testfn()'s result...")
    loop.run_until_complete(result_value)

    print("__main__: testfn() returned:", result_value.result())
    loop.close()
