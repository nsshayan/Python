class Tasklets:

    def __init__(self):
        from collections import deque
        self.runqueue = deque()

    def add(self, *args, **kwargs):
        def _decorator(fn):
            from types import GeneratorType
            tasklet = fn(*args, **kwargs)
            if type(tasklet) is not GeneratorType:
                raise TypeError("Argument fn() must be a generator")
            else:
                self.runqueue.append(tasklet)
        return _decorator

    def run(self):
        while self.runqueue:
            tasklet = self.runqueue[0]
            try:
                next(tasklet)
            except StopIteration:
                self.runqueue.popleft()
            else:
                self.runqueue.rotate(-1)

if __name__ == '__main__':
    tasks = Tasklets()

    @tasks.add(x=10)  # Add the below function into tasks runqueue
    def foo(x):
        for i in range(x):
            yield
            print("foo: counting {}".format(i))

    @tasks.add(n=5) # Add the below function into tasks runqueue
    def bar(n):
        for i in range(n):
            yield
            print("bar: counting {}".format(i))

    tasks.run() # Schedule tasklets (functions) added into tasks runqueue
