from threading import Thread, current_thread
from time import sleep

def foo(x):
    th = current_thread()
    for i in range(x):
        sleep(1)
        print(f"foo[{th.name}] counting {i}")

if __name__ == '__main__':
    t1 = Thread(target=foo, args=(10,), name="Test-Thread")
    t2 = Thread(target=foo, args=(20,), name="Monitor-Thread")

    t1.start()
    t2.start()

    foo(15)

    print("main complete...")
