from time import sleep
from threading import Thread

def foo(x):
    for i in range(x):
        print("foo: counting {}".format(i))
        if i == 3:
            while True:
                sleep(1)
                print("Foo running...")

def bar(n):
    for i in range(n):
        print("bar: counting {}".format(i))
        sleep(1)

if __name__ == '__main__':
    t1 = Thread(target=foo, args=(10,))
    t2 = Thread(target=bar, args=(20,))
    t1.start()
    t2.start()

    for i in range(15):
        print("In main: counting", i)
        sleep(1)
