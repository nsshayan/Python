from time import sleep


def foo():
    for i in range(10):
        print("In foo: counting", i)
        print("Sleeping in foo:", i)
        sleep(1)
        print("Woke up in foo:", i)


def bar():
    for i in range(10):
        print("In bar: counting", i)
        print("Sleeping in bar:", i)
        sleep(1)
        print("Woke up in bar:", i)


if __name__ == '__main__':
    foo()
    bar()
