from time import sleep
import asyncio

async def foo():
    for i in range(10):
        print("In foo: counting", i)
        await asyncio.sleep(1)


async def bar():
    for i in range(5):
        print("In bar: counting", i)
        await asyncio.sleep(1)

async def main():
    await asyncio.gather(foo(), bar())

if __name__ == '__main__':
    #loop = asyncio.get_event_loop()
    #loop.run_until_complete(asyncio.gather(
    #    foo(), bar()
    #))
    #loop.close()
    asyncio.run(main())
