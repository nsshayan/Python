from threading import Thread
from time import sleep

class Counter(Thread):
    def __init__(self, times):
        Thread.__init__(self)
        #super(Counter, self).__init__()
        self.times = times

    def run(self):
        for i in range(self.times):
            print(f"{self.name} counting {i}")
            sleep(0.5)

if __name__ == '__main__':
    for i in range(5):
        t = Counter(10)
        t.start()
