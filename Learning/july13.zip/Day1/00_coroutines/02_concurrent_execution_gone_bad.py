from time import sleep


def foo():
    for i in range(10):
        print("In foo: counting", i)
        yield
        print("Sleeping in foo:", i)
        sleep(1)
        print("Woke up in foo:", i)


def bar():
    for i in range(10):
        if i > 5:
            while True:
                print("Bar running forever...")
                sleep(0.5)

        print("In bar: counting", i)
        yield
        print("Sleeping in bar:", i)
        sleep(1)
        print("Woke up in bar:", i)


if __name__ == '__main__':

    a = foo()
    b = bar()

    #while True:
    #    next(a)
    #    next(b)

    for _, _ in zip(a, b):
        pass
