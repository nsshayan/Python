class Tasklets:

    def __init__(self):
        pass  # TODO

    def add(self, *args, **kwargs):
        pass  # TODO

    def run(self):
        pass # TODO

if __name__ == '__main__':
    tasks = Tasklets()

    @tasks.add(x=10)  # Add the below function into tasks runqueue
    def foo(x):
        for i in range(x):
            yield
            print("foo: counting {}".format(i))

    @tasks.add(n=5) # Add the below function into tasks runqueue
    def bar(n):
        for i in range(n):
            yield
            print("bar: counting {}".format(i))

    tasks.run() # Schedule tasklets (functions) added into tasks runqueue
