
def foo():
    print("In foo....")
    yield 100
    
    print("Back into foo...")
    yield "Hello world"
    
    print("Back again into foo...")
    yield
    
    print("End of foo...")
    