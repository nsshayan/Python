"""
Implement the 'Tasklets' class that allows adding generators into
a runqueue and schedule them.

Under the '__main__' namespace, the following is a sample use-case.
Running this program should generate result as below:
    foo: counting 0
    bar: counting 0
    foo: counting 1
    bar: counting 1
    foo: counting 2
    bar: counting 2
    foo: counting 3
    bar: counting 3
    foo: counting 4
    bar: counting 4
    foo: counting 5
    foo: counting 6
    foo: counting 7
    foo: counting 8
    foo: counting 9
"""

class Tasklets:
    def __init__(self):
        from collections import deque
        self.rq = deque()
    
    def add(self, fn, *args, **kwargs):
        t = fn(*args, **kwargs)
        self.rq.append(t)

    def run(self):
       while self.rq:
            t = self.rq[0]
            try:
                next(t)
            except StopIteration:
                self.rq.popleft()
            else:
                self.rq.rotate(-1)


if __name__ == '__main__':

    def foo(x):
        for i in range(x):
            yield
            print("foo: counting {}".format(i))
        for i in range(100):
            print("foo: counting {}".format(i))


    def bar(n):
        for i in range(n):
            yield
            print("bar: counting {}".format(i))

    tasklets = Tasklets()
    tasklets.add(foo, 5)
    tasklets.add(bar, 20)
    tasklets.run() # Schedule tasklets (generator functions) added into the runqueue

