from threading import Thread, current_thread
from time import sleep

def foo(x):
    th = current_thread()
    for i in range(x):
        sleep(1)
        print(f"foo[{th.name}] counting {i}")

def bar():
    from itertools import count
    for i in count():
        print(f"bar: counting {i}")
        sleep(1)

if __name__ == '__main__':
    t1 = Thread(target=foo, args=(2,), name="Test-Thread")
    t2 = Thread(target=bar, name="Monitor-Thread", daemon=True)

    t1.start()

    #t2.daemon = True
    t2.start()
    t1.join(timeout=3)
    if not t1.is_alive():
        print("foo completed...")
    print("main complete...")
