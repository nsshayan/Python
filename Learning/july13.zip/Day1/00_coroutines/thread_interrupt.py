from threading import Thread, current_thread, Event
from time import sleep

quit = Event()

def foo(x):
    th = current_thread()
    for i in range(x):
        if quit.wait(10):
            break
        print(f"foo[{th.name}] counting {i}")

if __name__ == '__main__':
    t1 = Thread(target=foo, args=(10,))

    t1.start()

    sleep(3)
    quit.set()
    t1.join()
    print("t1 completed...")