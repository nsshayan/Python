"""
Implement the 'Tasklets' class that allows adding generators into
a runqueue and schedule them.

Under the '__main__' namespace, the following is a sample use-case.
Running this program should generate result as below:
    foo: counting 0
    bar: counting 0
    foo: counting 1
    bar: counting 1
    foo: counting 2
    bar: counting 2
    foo: counting 3
    bar: counting 3
    foo: counting 4
    bar: counting 4
    foo: counting 5
    foo: counting 6
    foo: counting 7
    foo: counting 8
    foo: counting 9
"""
class TaskletsInefficient:
    def __init__(self):
        self.rq = []

    def add(self, fn, *args, **kwargs):
        g = fn(*args, **kwargs)
        self.rq.append(g)

    def run(self):
        while self.rq:
            for t in self.rq:
                try:
                    next(t)
                except StopIteration:
                    self.rq.remove(t)

class Tasklets:
    def __init__(self):
        from collections import deque
        self.rq = deque()

    def add(self, fn, *args, **kwargs):
        g = fn(*args, **kwargs)
        self.rq.append(g)

    def run(self):
        while self.rq:
            t = self.rq[0]
            try:
                next(t)
            except StopIteration:
                self.rq.popleft()
            else:
                self.rq.rotate(-1)


from time import sleep

from collections import deque
class Tasklets:
    def __init__(self):
        self.tasks = deque()

    def add(self, fn, *args, **kwargs):
        g = fn(*args, **kwargs)
        self.tasks.append(g)

    def run_old(self):
        while self.tasks:
            for t in self.tasks:
                try:
                    next(t)
                except StopIteration:
                    self.tasks.remove(t)

    def run(self):
        while self.tasks:
            t = self.tasks[0]
            try:
                next(t)
            except StopIteration:
                self.tasks.popleft()
            else:
                self.tasks.rotate(-1)

if __name__ == '__main__':

    def foo(x):
        for i in range(x):
            yield
            print("foo: counting {}".format(i))
            if i > 3:
                while True:
                    print("foo running...")

    def bar(n):
        for i in range(n):
            yield
            print("bar: counting {}".format(i))

    tasklets = Tasklets()
    tasklets.add(foo, 5)
    tasklets.add(bar, 20)
    tasklets.run() # Schedule tasklets (generator functions) added into the runqueue
