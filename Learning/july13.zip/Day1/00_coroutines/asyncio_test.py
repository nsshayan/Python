import asyncio


async def foo():
    for i in range(10):
        print("In foo: counting {}".format(i))
        await asyncio.sleep(1)


async def bar():
    for i in range(10):
        print("In bar: counting {}".format(i))
        await asyncio.sleep(1)

if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    loop.run_until_complete(
        asyncio.gather(
            foo(),
            bar()
        )
    )
    loop.close()
