from time import sleep


def foo():
    for i in range(10):
        print("In foo: counting", i)
        print("Sleeping in foo:", i)
        yield
        sleep(1)
        print("Woke up in foo:", i)


def bar():
    for i in range(5):
        print("In bar: counting", i)
        print("Sleeping in bar:", i)
        yield
        sleep(1)
        print("Woke up in bar:", i)


if __name__ == '__main__':
    g1 = foo()
    g2 = bar()
#    tasks = [g1, g2]
#    while tasks:
#        for coro in tasks:
#            try:
#                next(coro)
#            except StopIteration:
#                tasks.remove(coro)
#    from itertools import cycle
#    for coro in cycle(tasks):
#        try:
#            next(coro)
#        except StopIteration:
#            tasks.remove(coro)
    from collections import deque
    tasks = deque([g1, g2])
    while tasks:
        coro = tasks[0]
        try:
            next(coro)
        except StopIteration:
            tasks.popleft()
        else:
            tasks.rotate(-1)
