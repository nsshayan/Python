from gevent import monkey; monkey.patch_all()
from itertools import count
import gevent

from time import sleep

def foo(i):
    print("Created greenlet-{}".format(i))
    sleep(100)


greenlets = []

for i in count():
    g = gevent.spawn(foo, i)
    greenlets.append(g)
    gevent.sleep(0)
    
    