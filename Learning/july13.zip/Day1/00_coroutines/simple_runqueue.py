class Runqueue:
    def __init__(self):
        from collections import deque
        self.tasks = deque()

    def add_task(self, fn, *args, **kwargs):
        g = fn(*args, **kwargs)
        self.tasks.append(g)

    def schedule(self):
        while self.tasks:
            coro = self.tasks[0]
            try:
                next(coro)
            except StopIteration:
                self.tasks.popleft()
            else:
                self.tasks.rotate(-1)
