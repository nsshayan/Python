from threading import Thread, current_thread


class CounterThread(Thread):

    def __init__(self):
        Thread.__init__(self)
        #super(CounterThread, self).__init__()

    def run(self):
        for i in range(10):
            print(f"{self.name}: counting", i)

if __name__ == '__main__':
    t1 = CounterThread()
    t2 = CounterThread()
    t1.start()
    t2.start()
