from gevent import monkey
monkey.patch_all()

from itertools import count

from threading import Thread, current_thread

from time import sleep

def foo():
    t = current_thread()
    print("Created {}".format(t.name))
    sleep(100)


for i in count():
    t = Thread(target=foo)
    t.start()
