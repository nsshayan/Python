from time import sleep
from threading import Thread

def foo():
    for i in range(10):
        print("foo(): counting", i)
        if i > 5:
            while True:
                print("foo(): running forever")
                sleep(1)

        sleep(1)

def bar():
    for i in range(10):
        print("bar(): counting", i)
        sleep(1)

if __name__ == '__main__':
    t1 = Thread(target=foo)
    t2 = Thread(target=bar)

    t1.start()
    t2.start()

    for i in range(5):
        print("main: counting", i)
        sleep(1)

    print("main: exiting...")
