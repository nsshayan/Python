from time import sleep
import gevent

def foo():
    for i in range(10):
        print("foo(): counting", i)
        gevent.sleep(1)

def bar():
    for i in range(10):
        print("bar(): counting", i)
        gevent.sleep(1)

if __name__ == '__main__':
    t1 = gevent.spawn(foo)
    t2 = gevent.spawn(bar)
    gevent.wait([t1, t2])
