from gevent import monkey
monkey.patch_all()

from threading import Thread

print(Thread)

def foo():
    print("hello world")

t = Thread(target=foo)
print(t, type(t))
