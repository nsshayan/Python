class CommandDispatch:
    def __init__(self):
        self.dispatch = {}

    def for_command(self, command):
        def decorate(fn):
            self.dispatch[command] = fn
        return decorate


    def invalid(self, fn):
        self.invalid_command = fn

    def input(self, fn):
        self.input_command = fn

    def run(self):
        while True:
            args = self.input_command()
            command = args[0]
            #try:
            #    self.dispatch[command](*args)
            #except KeyError:
            #    self.invalid_command(*args)
            #if command in self.dispatch:
            #    self.dispatch[command](*args)
            #else:
            #    self.invalid_command(*args)
            self.dispatch.get(command, self.invalid_command)(*args)
