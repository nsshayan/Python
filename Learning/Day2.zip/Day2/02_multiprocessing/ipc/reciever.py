with open("data.pipe", "r") as src:
    for line in src:
        print "Got line: ", line

