with open("data.pipe", "w") as out:
    out.write("Hello world\n")
    out.write("lsjdf lsdjkljsdlkfjsdf\n")
    out.write("kdsjkljds lkfjsdfkljsdlkf\n")

