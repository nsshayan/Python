class Car:
    def __init__(self, name="Honda"):
        self.name = name

    def drive(self):
        print "Driving car", self.name

