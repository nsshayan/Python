from multiprocessing import Process as Task
from multiprocessing import current_process as current

#from threading import Thread as Task
#from threading import current_thread as current

from time import sleep
from multiprocessing import Value


#class Value:
#    def __init__(self, ctype, value):
#        self.value = value


def foo(n):
    print(f"In {current()}:foo: value = {n.value}")
    sleep(1)
    n.value = 500
    print(f"In {current()}:foo: value now is {n.value}")


def bar(n):
    print(f"In {current()}:bar: value = {n.value}")
    sleep(2)
    print(f"In {current()}:bar: value now is {n.value}")
    n.value = 200
    print(f"In {current()}:bar: value changed to {n.value}")


num = Value("i", 100)

t1 = Task(target=foo, args=(num,))
t2 = Task(target=bar, args=(num,))

t1.start()
t2.start()

t1.join()
t2.join()
print(f"In {current()}: value is {num.value}")
