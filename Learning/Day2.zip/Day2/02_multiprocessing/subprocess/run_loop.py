i = 0
from time import sleep
from sys import stdout

while True:
    print "Counting...", i
    i += 1
    #sleep(0.5)
    #stdout.flush()


