from math_server_stub import MathManager


manager = MathManager(address=('127.0.0.1', 6060),
                                    authkey=b"secret")


manager.connect()
math = manager.Maths()
print(math.add(10, 20))
print(math.mul(20, 30))
try:
    print(math.div(20, 0))
except Exception as e:
    print("Caught", e)
