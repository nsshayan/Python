from multiprocessing.managers import BaseManager

class MathsClass(object):
    def add(self, x, y):
        pass

    def mul(self, x, y):
        pass

    def div(self, x, y):
        pass


class MyManager(BaseManager): pass

MyManager.register('Maths', MathsClass)

# ------------------ main program --------------------
if __name__ == '__main__':
    manager = MyManager(address=('127.0.0.1', 6060), authkey="secret")

    manager.connect()
    math = manager.Maths()
    print math.add(10, 20)
    print math.mul(20, 30)
    print math.div(20, 0)





