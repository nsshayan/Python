from multiprocessing.managers import BaseManager


class MathsClass:
    def add(self, x, y):
        pass

    def mul(self, x, y):
        pass

    def div(self, x, y):
        pass


class MathManager(BaseManager): pass

MathManager.register('Maths', MathsClass)
