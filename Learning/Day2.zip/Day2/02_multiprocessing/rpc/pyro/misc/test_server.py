import Pyro4
from multiprocessing import Queue, Lock, Value, Event
import logging

results = {}

class JobQueue:
    def __init__(self):
        self.id = Value('i', 0)
        self.lock = Lock()
        self.queue = Queue(10)
        self.stats = {}
        self.update_stats = Event()

    def submit(self, fn, tests):
        with self.lock:
            self.id.value += 1
            self.queue.put((self.id.value, fn, tests))
            results[self.id.value] = Queue(1)
            self.stats[self.id.value] = dict(
                    fn=fn.__qualname__,
                    tests=str(tests),
                    status="submitted")
            job_id = self.id.value
        return job_id

    def setstats(self, job_id, status):
        with self.lock:

    def fetch(self):
        job = self.queue.get()
        with self.lock:
            self.stats[job[0]]["status"] = "assigned"
        return job

job_queue = JobQueue()

logging.basicConfig(
        filename='test_server.log',
        format='%(asctime)s %(message)s',
        level=logging.DEBUG)

@Pyro4.expose
class TestManager(object):
    def __init__(self):
        self.log = logging.getLogger("test.manager")
        self.log.info("TestManager() initialized")

    def submit_job(self, fn, tests):
        job_queue.submit(fn, tests)

    def submit_result(self, job_id, result):
        results[job_id].put(result)

if __name__ == '__main__':
    daemon = Pyro4.Daemon()
    ns = Pyro4.locateNS()
    uri = daemon.register(TestManager)
    ns.register("test.manager", uri)

    print("""Test Manager running:
             URI = {}
             NAME = test.manager""".format(uri))
    daemon.requestLoop()