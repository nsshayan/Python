import Pyro4

maths = Pyro4.Proxy("PYRONAME:math")
#maths = Pyro4.Proxy(uri)

print(maths.add(10, 20))
print(maths.mul(10, 20))

