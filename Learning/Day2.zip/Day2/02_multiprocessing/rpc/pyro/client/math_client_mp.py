from concurrent.futures import ProcessPoolExecutor as Executor
import Pyro4

maths = Pyro4.Proxy("PYRONAME:math")

data = [(10, 20), (40, 50), (60, 70)]

def run_remote(n):
    maths = Pyro4.Proxy("PYRONAME:math")
    return maths.add_nums(n)

with Executor(max_workers=4) as workers:
    result = workers.map(run_remote, data)

    # result = workers.map(maths.add_nums, data)
    
print(list(result))
#maths = Pyro4.Proxy(uri)
#
#print(maths.add(10, 20))
#print(maths.mul(10, 20))
