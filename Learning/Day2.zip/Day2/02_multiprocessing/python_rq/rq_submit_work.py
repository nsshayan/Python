from redis import Redis
from rq import Queue
from simple_task import add

q = Queue(connection=Redis(host="192.168.1.130"))
q.enqueue(add, 10, 20)
