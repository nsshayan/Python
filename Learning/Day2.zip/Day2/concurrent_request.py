#from concurrent.futures import ThreadPoolExecutor as Executor
from concurrent.futures import ProcessPoolExecutor as Executor

from time import sleep, time

def square(x):
    sleep(2)
    return x*x

def get_response(url):
    import requests
    print(f"GET {url}")
    status_code = requests.get(url).status_code
    print(f"GET {url} -> {status_code}")
    return (url, status_code)

if __name__ == '__main__':
    urls = [
        "https://www.chandrashekar.info/",
        "https://www.cisco.com/",
        "https://www.python.org/",
        "https://www.google.com/",
        "https://www.facebook.com/"
    ]

    start = time()

    #result = list(map(get_response, urls))

    with Executor(max_workers=10) as workers:
        result = workers.map(get_response, urls)

    duration = time() - start
    print(f"map() took {duration} seconds")
    print("result = ", list(result))


    #print(result)
