class User:
    def __init__(self, name, dept, role):
        self.name, self.dept, self.role = name, role, dept

    def info(self):
        print(f"Name: {self.name}, Role: {self.role}, Dept: {self.dept}")
