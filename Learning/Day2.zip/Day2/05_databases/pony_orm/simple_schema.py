from pony.orm import *

db = Database()
#set_sql_debug(True)

class Staff(db.Entity):
    name = Required(str)
    age = Required(int)
    cars = Set('Car')

class Car(db.Entity):
    make = Required(str)
    owner = Required(Staff)
    price = Required(int)

db.bind(provider="sqlite", filename="staff.db", create_db=True)
db.generate_mapping(create_tables=True)

with db_session:
    p = Staff(name='John', age=47)
    c = Car(make="Maruti", price=450000, owner=p)

with db_session:  # SELECT * FROM Staff WHERE age > 20
    for row in select(p for p in Staff if p.age > 20):
        print(row.name, [ c.price for c in row.cars ])

with db_session:
    s = Staff[1]
    s.name = "Jane"

with db_session:
    for row in select(p for p in Staff if p.age > 20):
        print(row.name, [ c.price for c in row.cars ])
