from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, create_engine
from sqlalchemy.orm import sessionmaker

Base = declarative_base()


class User(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True)
    name = Column(String)
    fullname = Column(String)
    password = Column(String)

    def __repr__(self):
        return f"User(name='{self.name}', fullname='{self.fullname}', password='{self.password}')"


if __name__ == '__main__':
    #engine = create_engine("mysql://user:password@host:port/database")
    engine = create_engine("sqlite:///testdb")
    Base.metadata.create_all(engine)  # CREATE TABLE query

    Session = sessionmaker(bind=engine)

    session = Session()

    user1 = User(name="smith", fullname="John smith", password="smith123")
    session.add(user1)  # INSERT query
    session.add_all([
        User(name='wendy', fullname='Wendy Williams', password='foobar'),
        User(name='mary', fullname='Mary Contrary', password='xxg527'),
        User(name='fred', fullname='Fred Flinstone', password='blah')])
    session.commit()

    # SELECT * FROM users WHERE name='smith'
    u = session.query(User).filter_by(name='smith').first()
    print(u)

    # SELECT name, fullname FROM users
    for name, fullname in session.query(User.name, User.fullname):
        print(name, fullname)
