import sqlite3 as driver
from hashlib import sha224 as crypt
from getpass import getpass

SELECT_SQL = """
  SELECT name, password, fullname FROM users
         WHERE name = ? AND password = ?
"""

with driver.connect("userdb") as conn:
    username = input("Enter username: ")
    password = crypt(bytes(getpass("Enter password: "), "utf8")).hexdigest()

    users = conn.execute(SELECT_SQL, (username, password))
    record = users.fetchone()
    if record:
        print(f"Hello {record[2]}, Welcome to Python")
    else:
        print("Authentication failure")
