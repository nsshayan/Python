import sqlite3 as driver
from hashlib import sha224 as crypt

create_sql = """
CREATE TABLE users(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(32) UNIQUE,
    password VARCHAR(128),
    fullname VARCHAR(32)
 )
"""

insert_sql = """
INSERT INTO users(name, password, fullname) VALUES(?,?,?)
"""

conn = driver.connect("userdb")

users = conn.cursor()
users.execute(create_sql)

while True:
    name = input("Enter username: ")
    password = crypt(bytes(input("Enter password: "), "utf8")).hexdigest()
    fullname = input("Enter fullname: ")
    users.execute(insert_sql, (name, password, fullname))
    choice = input("Add new user (yes/no) ?")
    if choice[0].upper() != "Y":
        break

conn.commit()
conn.close()
