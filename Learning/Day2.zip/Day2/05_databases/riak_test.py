from riak import RiakClient

connection = RiakClient()

test_bucket = connection.bucket("test_bucket")

book = {
    'isbn': "1111979723",
    'title': "Moby Dick",
    'author': "Herman Melville",
    'body': "Call me Ishmael. Some years ago...",
    'copies_owned': 3
}

b = test_bucket.new(book["isbn"], data=book)
b.store()

c = test_bucket.get(book['isbn'])
print(c.encoded_data)
print(c.data)
