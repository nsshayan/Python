from falsy.falsy import FALSY

f = FALSY()
f.swagger('simple.yml', ui=True, theme='impress') 
api = f.api
