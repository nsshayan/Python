from flask import Flask
from flask_restful import reqparse, Resource, Api

app = Flask(__name__)
api = Api(app)

parser = reqparse.RequestParser()
parser.add_argument("title")
parser.add_argument("data")


class HelloWorld(Resource):
    def get(self):
        return {'hello': 'world'}

    def post(self):
        data = parser.parse_args()
        print("Got data:", data)
        return data, 201

api.add_resource(HelloWorld, '/posts')

if __name__ == '__main__':
    app.run(debug=True)
