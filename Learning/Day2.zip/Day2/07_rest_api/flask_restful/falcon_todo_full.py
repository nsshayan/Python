import falcon
import json

TODOS = {
    'todo1': {'task': 'build an API'},
    'todo2': {'task': '?????'},
    'todo3': {'task': 'profit!'},
}


def abort_if_todo_doesnt_exist(todo_id, resp):
    if todo_id not in TODOS:
        resp.status = falcon.HTTP_404
        resp.data = "Todo {} does not exist".format(todo_id)
        return True
    else:
        return False


# Todo
# shows a single todo item and lets you delete a todo item
#class Todo:
#    def on_get(self, req, resp):
#        if not abort_if_todo_doesnt_exist(todo_id, resp):
#            resp.status = falcon.HTTP_200
#            resp.media = TODOS[req.]


#    def delete(self, todo_id):
#        abort_if_todo_doesnt_exist(todo_id)
#        del TODOS[todo_id]
#        return '', 204

#    def put(self, todo_id):
#        args = parser.parse_args()
#        print(args)
#        task = {'task': args['task'], 'name': args['name']}
#        TODOS[todo_id] = task
#        return task, 201


class TodoList:
    def on_get(self, req, resp):
        resp.status = falcon.HTTP_200
        #resp.data = bytes(json.dumps(TODOS), "utf8")
        resp.data = bytes()

    def on_post(self, req, resp):
        args = req.json()

        if not args["task"]:
            resp.status = falcon.HTTP_400
            resp.data = "Invalid format, no task defined"
            return

        todo_id = int(max(TODOS.keys()).lstrip('todo')) + 1
        todo_id = 'todo%i' % todo_id
        TODOS[todo_id] = {'task': args['task'], 'name': args['name']}
        resp.status = falcon.HTTP_201
        resp.data = "Task added."


api = falcon.API()
api.add_route('/todos', TodoList())
 #   api.add_route('/todos/<todo_id>', Todos())

