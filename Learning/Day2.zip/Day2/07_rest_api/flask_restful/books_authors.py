from flask import Flask
from flask_restful import Resource, Api

app = Flask(__name__)
api = Api(app)

class Book(Resource):
    def get(self):
        return {'name': 'A silly book'}

    def post(self, *args, **kwargs):
        print("Post method called with on Book {},  {}".format(args, kwargs))

class Author(Resource):
    def get(self):
        return {'name': "John Doe"}

    def post(self, *args, **kwargs):
        print("Post method called with on Author {},  {}".format(args, kwargs))

api.add_resource(Book, "/books")
api.add_resource(Author, "/author")

if __name__ == '__main__':
    app.run(debug=True)
