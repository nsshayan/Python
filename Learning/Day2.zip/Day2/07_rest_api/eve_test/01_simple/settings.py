DOMAIN = {'people': {}}
#MONGO_HOST = 'localhost'
#MONGO_PORT = 27017

#MONGO_USERNAME = '<your username>'
#MONGO_PASSWORD = '<your password>'

MONGO_DBNAME = 'apitest'
