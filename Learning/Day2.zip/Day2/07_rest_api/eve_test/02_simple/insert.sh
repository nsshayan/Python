#!/bin/sh

curl -d '[{"firstname": "steven", "lastname": "bourne"}, {"firstname": "david", "lastname": "korn"}, {"firstname": "guido", "lastname": "rossum"}]' -H 'Content-Type: application/json' http://127.0.0.1:5000/people
