from eve import Eve
app = Eve()

if __name__ == '__main__':
    app.run()
