from flask import Flask, render_template, request, make_response

app = Flask(__name__)


@app.route("/")
def hello():
    #r.headers["Content-Type"] =
    return "Hello World!"

@app.route("/", methods=["PUT"])
def hello_put():
    resp = make_response("Welcome to Python!", 407)
    return resp

@app.route("/welcome/<user>")
def welcome(user):
    print(request.args)
    #return f"<h1>Welcome <i>to</i> Python, {user}</h1>"
    return render_template("home.html",
                            username=user, city="Mumbai")

@app.route("/div")
def divide():
    a = int(request.args.get('a', 4))
    b = int(request.args.get('b', 2))
    return f"<h1><strong>{a / b}</strong></h1>"

@app.route("/about")
def about():
    a / b
    return "<h1>this is about page</h1>"


# @app.route("/list/<int:page>")
# def dircontents(page):

@app.route("/list")
def dircontents():
    page = int(request.args.get("page", 0))
    n_elements = 5
    import os
    # filedata = []
    # for f in os.listdir("."):
    #    filedata.append((f, os.path.getsize(f), os.path.getmtime(f))
    files = [(f, os.path.getsize(f), os.path.getmtime(f))
             for f in os.listdir(".")]
    #
    start = page + (page * n_elements)
    end = start + n_elements
    return render_template("listdir.html",
                           filedata=files[start:end],
                           name="listing directory",
                           pages=list(range(1, (len(files)//n_elements)+1)))



if __name__ == "__main__":
    app.run(debug=True)
