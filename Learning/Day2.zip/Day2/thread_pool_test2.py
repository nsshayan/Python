
from thread_pool_simple import ThreadPool
from time import sleep, time

if __name__ == '__main__':

    def square(x):
        from time import sleep
        sleep(0.5)
        return x*x

    with ThreadPool(workers=10) as pool:
        start = time()
        result = pool.map(square, list(range(10, 100, 5)))
        duration = time() - start
        print(f"result = {result}, took {duration} seconds")