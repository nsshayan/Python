from queue import Queue

class ThreadPool:
    class Error(Exception): pass

    def __init__(self, workers, capacity=None):
        from threading import Thread
        self.workers = workers
        self.capacity = capacity if capacity else workers
        self.pool = {}
        self.queue = Queue(self.capacity)
        self.ready = False
        for i in range(self.workers):
            self.pool[i] = Thread(target=self.__wait_on_queue)

    def __enter__(self):
        self.ready = True
        for i in range(self.workers):
            self.pool[i].start()
        return self

    def map(self, fn, data):
        size = len(data)

        result = Queue(size)

        for element in data:
            self.queue.put((fn, result, (element,), {}))

        return [ result.get() for i in range(size) ]



    def __wait_on_queue(self):
        while self.ready:
            fn, result, args, kwargs = self.queue.get()
            if fn is None: continue
            result.put(fn(*args, **kwargs))

    def __exit__(self, ev, et, tb):
        self.ready = False
        for i in range(self.workers):
            self.queue.put((None, None, None, None))

    def submit(self, fn, args=(), kwargs={}):
        result = Queue(1)
        self.queue.put((fn, result, args, kwargs))
        return result

