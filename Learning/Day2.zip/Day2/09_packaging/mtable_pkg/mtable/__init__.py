from . import table
from table import gen_table
