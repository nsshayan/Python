from threading import Thread, Event
from queue import Queue

class ThreadPool:
    def __init__(self, workers):
        self.queue = Queue(workers*2)
        self.threads = []
        self.shutdown = Event()

        for _ in range(workers):
            th = Thread(target=self.__wait_on_queue)
            self.threads.append(th)

    def __wait_on_queue(self):
        while not self.shutdown.is_set():
            work = self.queue.get()
            if work is None:
                continue
            work.perform()

    def submit(self, fn, args=(), kwargs={}):
        work = Future(fn, args, kwargs)
        self.queue.put(work)
        work.state = "Pending on queue"
        return work

    def start(self):
        for t in self.threads:
            t.start()

    def stop(self):
        self.shutdown.set()
        for _ in range(self.queue.maxsize - self.queue.qsize()):
            self.queue.put(None)

class Future:
    def __init__(self, fn, args=(), kwargs={}):
        self.fn = fn
        self.args = args
        self.kwargs = kwargs
        self.ready = False
        self.ready_event = Event()
        self.state = "Created"
        self.result_value = None

    def result(self):
        self.ready_event.wait()
        return self.result_value

    def perform(self):
        self.state = "In-flight"
        self.result_value = self.fn(*self.args, **self.kwargs)
        self.ready = True
        self.ready_event.set()
        self.state = "Completed"
