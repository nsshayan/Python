from flask import Flask, request

app = Flask("my_app")

posts = [
    {"id": 1, "title": "this is first post"},
    {"id": 2, "title": "this is second post"},
    {"id": 3, "title": "this is third post"}
]


@app.route("/")
def hello():
    return "<h1>Hello world</h1>"


@app.route("/about")
def about_page():
    return "<h1>This is my about web page</h1>"


@app.route("/posts", methods=["GET", "POST"])
def blog():
    if request.method == "POST":
        return
    elif request.method == "GET":
        return posts["test"]


@app.route("/posts/<int:post_id>")
def get_post(post_id):
    import json
    print("get_post...")
    return json.dumps(posts[post_id - 1])


@app.route("/users/<int:user_id>")
def users(user_id):
    print("user_id =", user_id)
    return "Hello " + str(user_id)


if __name__ == '__main__':
    app.run(debug=True)
# app.run()
