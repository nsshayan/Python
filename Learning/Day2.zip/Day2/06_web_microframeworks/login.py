from flask import Flask
from flask import request, redirect, url_for
app = Flask(__name__)

@app.route("/")
def index_page():
    return open("login.html").read().format(
                    header="User Login",
                    action="/login")



@app.route("/login", methods=["POST"])
def authenticate():
    if request.method == "POST":
        print("Login attempted with username {} password {}".format(
               request.form["uname"], request.form["password"]))
        if request.form["uname"] == "john" and request.form["password"] == "john123":
            return redirect("/home")
        else:
            return "Authentication failed"


@app.route("/home")
def welcome():
    return open("home.html").read().format(username="john")


@app.route("/logout")
def logout():
    return redirect("/")


if __name__ == "__main__":
    app.run(debug=True)
