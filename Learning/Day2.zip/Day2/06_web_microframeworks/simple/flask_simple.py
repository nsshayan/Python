from flask import Flask, request, render_template, make_response

app = Flask("my_app")

@app.route("/")
def hello_world():
    return render_template("index.html")

@app.route("/about")
def about_me():
    #return "<h1>I am a silly/small Flask application</h1>"
    response = make_response()

    response.headers["Content-Type"] = "image/png"
    data = open("python_new_style_oo.png", "rb").read()
    #response.headers["Content-Length"] = len(data)
    response.headers["Transfer-Encoding"] = "chunked"
    response.stream = open("./python_new_style_oo.png", "rb")
    return response

@app.route("/hello/<name>")
def hello(name):
    return "<h1>Hello <i>{}</i>, Welcome to Flask</h1>".format(name)

@app.route("/login")
def login():
    username, password = request.values["name"], request.values["password"]
    return render_template("login.html", name=username, password=password)

if __name__ == '__main__':
    app.run(debug=True)
