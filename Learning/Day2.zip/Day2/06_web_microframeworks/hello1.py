from flask import Flask

app = Flask("my_new_app")


@app.route("/")
def hello():
    return "Hello World!"


@app.route("/about")
def about():
    return "<h1>This is about page</h1>"


@app.route("/greet/<name>/<place>/<score>")
def greet(name, place, score):
    return "<h1>Welcome to {} - {}, score = {}</h1>".format(place, name, score*10)


if __name__ == '__main__':
    app.run(debug=True)
