from flask import Flask, session
app = Flask(__name__)
app.secret_key = "secret123"

data = {}


@app.route("/counter")
def show_count():

    if "count" not in data:
        data["count"] = 0

    v = data["count"]
    data["count"] += 1

    if "count" not in session:
        session["count"] = 0

    s = session["count"]
    session["count"] += 1

    return "<h1>Data count: {}, Session count: {}</h1>".format(v, s)


@app.route("/reset")
def reset():
    v = session["count"]
    del session["count"]
    del data["count"]

    return "<h1>Resetting (current value is {}, {})".format(v, s)


if __name__ == "__main__":
    app.run(port=5000, debug=True)
