from flask import Flask, make_response, request, Response
app = Flask(__name__)
app.secret_key = "welcome123"


#data = {"count" : 0}


@app.route("/")
def hello():
    #v = data["count"]
    #data["count"] += 1

    #    if "count" not in session:
    #        session["count"] = 0
    #    session["count"] += 1
    #    print session["count"]

    response = make_response("")

    if "count" not in request.cookies:
        response.set_cookie("count", str(0), 120)
        response.data = "Hello world!"
        return response

    else:
        response.set_cookie("count", str(
            int(request.cookies["count"]) + 1), 120)
        response.data = "Hello world, Count = %s" % request.cookies["count"]
        return response


@app.route("/raw")
def raw_response():
    return Response("this is a test data", direct_passthrough=True)


if __name__ == "__main__":
    app.run(port=5000, debug=True)
