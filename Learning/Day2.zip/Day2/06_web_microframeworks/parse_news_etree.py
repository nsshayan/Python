import xml.etree.ElementTree as et
import requests
from flask import *

news_url = "http://toi.timesofindia.indiatimes.com/rssfeedstopstories.cms"

app = Flask(__name__)

@app.route("/")
def show_news():
    r = requests.get(news_url)
    rootElement = et.fromstring(r.content)
    news = []
    for item in rootElement.findall('./channel/item'):
        title, date = item.find("./title").text, item.find("./pubDate").text
        news.append(dict(title=title, date=date))

    return render_template("news.html", news_data=news)


if __name__ == '__main__':
    app.run(debug=True)

