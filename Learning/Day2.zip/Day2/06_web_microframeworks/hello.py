from flask import Flask, render_template, request

app = Flask("my_app")


@app.route("/")
def hello():
    return "Welcome to Python World!"


@app.route("/welcome")
def welcome():
    #print(request.args)
    return "<h1>Welcome <i>to</i> new Python</h1>"


@app.route("/about")
def about():
    a = 3
    b = 0
    c = a / b
    return "<h1>this is about page</h1>"


# @app.route("/list/<int:page>")
# def dircontents(page):

@app.route("/list")
def dircontents():
    page = int(request.args.get("page", 0))
    n_elements = 5
    import os
    # filedata = []
    # for f in os.listdir("."):
    #    filedata.append((f, os.path.getsize(f), os.path.getmtime(f))
    files = [(f, os.path.getsize(f), os.path.getmtime(f))
             for f in os.listdir(".")]
    #
    start = page + (page * n_elements)
    end = start + n_elements
    return render_template("listdir.html",
                           filedata=files[start:end],
                           name="listing directory",
                           pages=list(range(1, (len(files)//n_elements)+1)))

    # Jinja2 rendering engin

if __name__ == "__main__":
    app.run(debug=True)
