from flask import Flask, Response, render_template

app = Flask("my_app")

def read_data():
    from time import sleep
    for i in range(10):
        yield str(i)
        sleep(2)


@app.route("/")
def hello():
    return Response(read_data(), mimetype="text/plain")

@app.route("/welcome")
def welcome():
    return "<h1>Welcome <i>to</i> Python</h1>"

@app.route("/about")
def about():
    return "<h1>this is about page</h1>"

@app.route("/list")
def dircontents():
    import os
    #filedata = []
    #for f in os.listdir("."): 
    #    filedata.append((f, os.path.getsize(f), os.path.getmtime(f))
    files = [ (f, os.path.getsize(f), os.path.getmtime(f)) \
                  for f in os.listdir(".") ]
    
    return render_template("listdir.html", filedata=files, 
                            name="listing directory")
    

if __name__ == "__main__":
    app.run(debug=True)
