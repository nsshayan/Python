from flask import *
app = Flask(__name__)


@app.route("/")
def index():
    return render_template("login.html",
                           header="User Login",
                           error=None,
                           action=url_for('authenticate'))


@app.route("/login", methods=["POST", "GET"])
def authenticate():
    if request.method == "POST":
        if request.form["uname"] == "john" and request.form["password"] == "john123":
            return redirect(url_for('welcome'))
        else:
            return render_template("login.html",
                                   header="User Login",
                                   error="Invalid username/password",
                                   action=url_for('authenticate'))
    else:
        return "<h1>GET request not allowed</h1>"


@app.route("/home")
def welcome():
    return render_template("home.html", username="john")


@app.route("/logout")
def logout():
    return redirect(url_for("index"))


if __name__ == "__main__":
    app.run(debug=True)
