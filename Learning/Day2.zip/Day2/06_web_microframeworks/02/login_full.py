from flask import *
app = Flask(__name__)
app.secret_key = "welcome123"


def need_login(f):
    def wrapper(*args, **kwargs):
        if "logged_in" not in session:
            return redirect(url_for('index'))
        else:
            return f(*args, **kwargs)
    wrapper.__qualname__ = f.__qualname__
    wrapper.__name__ = f.__name__
    return wrapper


@app.route("/")
def index():
    if "logged_in" in session:
        return redirect(url_for('welcome'))
    else:
        return render_template("login.html",
                               header="User Login",
                               error=None,
                               action=url_for('authenticate'))


@app.route("/login", methods=["POST"])
def authenticate():
    if request.method == "POST":
        if request.form["uname"] == "john" and request.form["password"] == "john123":
            session["logged_in"] = True
            return redirect(url_for('welcome'))
        else:
            return render_template("login.html",
                                   header="User Login",
                                   username=request.form["uname"],
                                   error="Invalid username/password",
                                   action=url_for('authenticate'))


@app.route("/home")
@need_login
def welcome():
    return render_template("home.html", username="john")


@app.route("/logout")
@need_login
def logout():
    del session["logged_in"]
    return redirect(url_for("index"))


if __name__ == "__main__":
    app.run(debug=True)
