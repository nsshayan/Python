
from concurrent.futures import ThreadPoolExecutor as Executor
#from concurrent.futures import ProcessPoolExecutor as Executor
from multiprocessing import cpu_count

from time import sleep, time

def long_loop(x):
    j = 0
    print(f"long_loop({x}):", end="", flush=True)
    for i in range(100000000):
        j += i
    print("complete.")
    return j


if __name__ == '__main__':
    nums = [10, 20, 30, 40, 50, 60]

    start = time()

    #result = list(map(long_loop, nums))

    with Executor(max_workers=cpu_count()) as workers:
       result = workers.map(long_loop, nums)

    duration = time() - start
    print(f"map() took {duration} seconds")
    print("result = ", list(result))


    #print(result)
