"""
Implement 'thread_pool' module hosting 'ThreadPool'
class that allows us to create a pool of worker threads
waiting on a job-queue for any jobs (functions) to be
submitted.

Implement the ThreadPool class such that the code within
the '__main__' namespace works.

[ This code is available at
 https://dhrona.net/p/apy ]

"""
#from thread_pool import ThreadPool
from concurrent.futures import ThreadPoolExecutor as Executor
#from concurrent.futures import ProcessPoolExecutor as Executor

if __name__ == '__main__':

    def foo(x, y):
        print("foo called: x = {}, y = {}".format(x, y))
        return x + y

    def bar(x, y):
        print("bar called: x = {}, y = {}".format(x, y))
        return x * y

    def test(x):
        print("test called: x = {}".format(x))
        return x ** x

    def square(x):
        #from time import sleep
        #sleep(0.5)
        return x*x

    #with Executor(max_workers=10) as pool:
    #    foo_result = pool.submit(foo, 10, 20)
    #    bar_result = pool.submit(bar, "Hello", 10)
    #    test_result = pool.submit(test, 100)

    #print(foo_result.result(), bar_result.result(), test_result.result())

    from time import time

    #start = time()
    #result = list(map(square, range(20)))
    #duration = time() - start
    #print("map took {} seconds".format(duration))
    #print("result =", result)

    start = time()
    with Executor(max_workers=10) as pool:
        result = pool.map(square, range(20))
    duration = time() - start

    #print("pool.map took {} seconds".format(duration))
    #print("result =", list(result))

    #from multiprocessing import Pool
    # with Pool(processes=10) as pool:
    #    result = pool.map(square, range(20))

    #duration = time() - start
    #print("Computed result in {} seconds".format(duration))
    print([x for x in result if x % 5 == 0])

    #final_values = []
    #for x in result:
    #    if x % 5 == 0:
    #        final_values.append(x)
    #print(final_values)
