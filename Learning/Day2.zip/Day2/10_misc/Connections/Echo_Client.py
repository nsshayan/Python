from multiprocessing.connection import Client

address = ('localhost', 6000)

conn = Client(address)

while True:
    line = raw_input("Enter line: ")
    if not line: break
    conn.send_bytes(line)
    response = conn.recv_bytes()
    print "Server response: ", response

conn.close()
