from multiprocessing.connection import Client

address = ('localhost', 6000)
conn = Client(address)
print conn.recv()                 
print conn.recv_bytes()            # => 'hello'
conn.close()
