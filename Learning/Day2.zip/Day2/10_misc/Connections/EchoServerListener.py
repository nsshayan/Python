from multiprocessing.connection import Listener


def handle_connection(client):
    client.send_bytes('Welcome to Echo Server\r\n')
    while True:
         data = client.recv_bytes()
         client.send_bytes(data.upper())
         if "bye" in data:
             break
    client.close()

address = ('localhost', 6000)
listener = Listener(address)

while True:
    conn = listener.accept()
    print 'connection accepted from', listener.last_accepted
    handle_connection(conn)

listener.close()
