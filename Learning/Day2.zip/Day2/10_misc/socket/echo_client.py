from socket import socket, AF_INET, SOCK_STREAM

sock = socket(AF_INET, SOCK_STREAM)
sock.connect(("127.0.0.1", 7070))

while True:
    line = raw_input("Enter line: ")
    sock.send(line)
    if not line: break
    reply = sock.recv(len(line))
    print "Server replied: ", reply

