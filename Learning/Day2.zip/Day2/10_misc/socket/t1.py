from time import sleep
from threading import Thread
#from multiprocessing import Process as Thread

interrupt = False

def foo():
    for i in range(10):
        if interrupt: raise ValueError, "sdfsdsdf"
        print "Foo: counting", i
        sleep(1)

def bar():
    for i in range(10):
        print "Bar: counting", i
        sleep(1)

t1 = Thread(target=foo)
t2 = Thread(target=bar)

t1.start()
t2.start()

sleep(5)
interrupt = True
#exit(0)

#t1.join()
#t2.join()

#foo()
#bar()

