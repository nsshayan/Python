from socket import socket, AF_INET, SOCK_STREAM

server = socket(AF_INET, SOCK_STREAM)

server.connect(("localhost", 8080))

data = server.recv(100)

print "Server replied: ", data




