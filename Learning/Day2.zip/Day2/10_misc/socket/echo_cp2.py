from socket import socket, AF_INET, SOCK_STREAM
from time import ctime
from threading import Thread
from multiprocessing import Process, Pool, Queue

CAPACITY = 10
queue = Queue(CAPACITY)
 
def handle_connection(c):
    print "Handling client: ", c
    while True:
        line = c.recv(100)
        if not line: break
        c.send(line.upper())
    c.close()


listener = socket(AF_INET, SOCK_STREAM)
listener.bind(("localhost", 7070))
listener.listen(10000)

workers = Pool(CAPACITY)
workers.map(handle_connection, queue)

while True:
    print "Waiting for connection: "
    client, addr = listener.accept()
    print "Got connection from client: ", addr
    pool.put(client)
