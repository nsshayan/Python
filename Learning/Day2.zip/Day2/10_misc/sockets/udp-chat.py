#!/usr/bin/env python
from socket import *
import thread
from os import fork

CHAT_PORT = 62340

def read_message(sock):
   while True:
      (message, (host, port)) = sock.recvfrom(255)
      print "%s> %s\n" % (message, host)

def send_message(sock):
   while True:
      input = raw_input("You> ")
      if input is not '':
         sock.sendto(input, ('192.168.1.255', CHAT_PORT))


s = socket(AF_INET, SOCK_DGRAM)
s.bind(('192.168.1.255', CHAT_PORT))

s.setsockopt(SOL_SOCKET, SO_BROADCAST, 1)

pid = fork()            # s1 = s.dup()
if pid == 0:            # thread.start_new_thread(send_message, (s,))
   send_message(s)      # thread.start_new_thread(read_message, (s1,))
elif pid > 0:
   read_message(s)

