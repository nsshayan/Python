#!/usr/bin/env python
from socket import socket, AF_INET, SOCK_STREAM
from os.path import basename

mySocket = socket(AF_INET, SOCK_STREAM)
mySocket.connect(("127.0.0.1", 5050))

filename = raw_input("Enter filename: ")
inputfile = open(filename, "r")
contents = inputfile.read()
inputfile.close()

header = "Filename: %s, Filesize: %d\n" % (basename(filename), len(contents))
header += " " * (1024 - len(header))

contents = header + contents

mySocket.send(contents)
mySocket.close()








