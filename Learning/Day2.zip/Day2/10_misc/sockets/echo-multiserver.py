#!/usr/bin/env python
from socket import socket, AF_INET, SOCK_STREAM
import thread

def handle_connection(client):
	while True:
		data = client.recv(50)
		print "Client sent: " + data
		data = data.strip()
		client.send(data.upper())
		if data.endswith("bye"):
			break
	client.close()
		
mySocket = socket(AF_INET, SOCK_STREAM)
mySocket.bind(("127.0.0.1", 5050))

print "Echo server listening on port 5050\n"
mySocket.listen(5)

while True:
	(client, addr) = mySocket.accept()
	print "Got incoming connection from: " + `addr`
	thread.start_new_thread(handle_connection, (client,))







