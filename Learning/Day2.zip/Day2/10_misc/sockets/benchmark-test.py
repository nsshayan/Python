#!/usr/bin/env python
from time import time

for i in range(15):
    start = time()
    for i in range(1000000):
        pass

    duration = time() - start

    print "duration = %f" % duration

