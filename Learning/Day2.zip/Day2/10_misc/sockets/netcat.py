#!/usr/bin/env python
from socket import socket, AF_INET, SOCK_STREAM
import sys

mySocket = socket(AF_INET, SOCK_STREAM)
mySocket.connect((sys.argv[1], int(sys.argv[2])))

try:
	while True:
		input = raw_input("")
		mySocket.send(input)
		data = mySocket.recv(1024)
except:
	mySocket.close()
	





