#!/usr/bin/env python
from socket import socket, AF_INET, AF_UNIX, SOCK_DGRAM
from time import sleep

mySocket = socket(AF_INET, SOCK_DGRAM)

while True:
    mySocket.sendto("Time please!",  ("127.0.0.1", 5000))
    (data, addr) = mySocket.recvfrom(50)
    print "Recieved time from server: " + `addr` + ":" + data
    sleep(2)
