#!/usr/bin/env python
from socket import *
import thread
import marshal

def handle_connection(client):
   client.send("server> ")
   input = client.recv(16384)
   print input
   print "---------------------"
   code = marshal.loads(input)
   exec code
   client.close()

try:
  server = socket(AF_INET, SOCK_STREAM)
  server.bind((gethostbyname(gethostname()), 5050))
  
  server.listen(SOMAXCONN)

  while True:
     (client, (host, port)) = server.accept()
     thread.start_new_thread(handle_connection, (client,))
except error, e:
  print "Socket Error ", e

