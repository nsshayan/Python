from itertools import count
import gevent
threads = []


def fn(i):
    from time import sleep
    print("New greenlet spawned: ", i)
    sleep(60)


for i in count(1):
    t = gevent.spawn(fn, i)
    print("Created greenlet {}: {}".format(i, t))
    threads.append(t)
