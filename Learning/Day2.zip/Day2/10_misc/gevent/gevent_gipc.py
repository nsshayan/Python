import gipc
import gevent

from random import randint, random
from time import sleep

def reader(q):
    while True:
        print("reader waiting for data...")
        v = q.get()
        sleep(5)
        print("reader for value:", v)

def writer(n, q):
    while True:
        data = randint(10, 50)
        print(n, "sending data:", data)
        q.put(data)
        print(n, "sent data...")

if __name__ == '__main__':
    with gipc.pipe() as (r, w):
        #p = Process(target=reader, args=(queue,))
        #p.start()

        p = gipc.start_process(target=reader, args=(r,))

        
        greenlets = []

        for i in range(10):
            g = gevent.spawn(writer, "greenlet-%d" % i, w)
            greenlets.append(g)
        
        gevent.joinall(greenlets)
        p.join()



