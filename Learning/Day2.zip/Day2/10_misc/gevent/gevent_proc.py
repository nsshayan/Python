import gevent

from multiprocessing import Process, Queue
from random import randint, random
from time import sleep


def reader(q):
    while True:
        print("reader waiting for data...")
        v = q.get()
        sleep(5)
        print("reader for value:", v)

def writer(n, q):
    while True:
        data = randint(10, 50)
        print(n, "sending data:", data)
        q.put(data)
        print(n, "sent data...")
        gevent.sleep(0)

if __name__ == '__main__':
    queue = Queue(1)
    p = Process(target=reader, args=(queue,))
    p.start()
    
    greenlets = []

    for i in range(10):
        g = gevent.spawn(writer, "greenlet-%d" % i, queue)
        greenlets.append(g)
    
    gevent.joinall(greenlets)
    p.join()



