from gevent.server import StreamServer
output = b"""
200 OK
Content-Type: text/html

<html>
<h1>It worked</h1>
</html>
"""

def handle(socket, address):
    data = socket.recv(72)
    print("Got {}".format(data))
    socket.send(output)
    socket.close()

server = StreamServer(('127.0.0.1', 5000), handle)
server.serve_forever()
