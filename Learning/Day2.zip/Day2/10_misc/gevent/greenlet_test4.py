from gevent import Greenlet
from gevent import sleep
#from time import sleep
import gevent

def foo(name):
    for i in range(10):
        print(name, i)
        sleep(0)

workers = {}
for i in range(10000):
    workers[i] = Greenlet(foo, "worker-%d" % i)
    workers[i].start()


gevent.wait(workers.values())



