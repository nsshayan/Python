import gevent
from gevent import Greenlet

import threading

def foo():
    for i in range(10):
        print("In foo: counting", i)
        gevent.sleep(0)

def bar():
    for i in range(10):
        print("In bar: counting", i)
        gevent.sleep(0)

if __name__ == '__main__':
    foo_greenlet = Greenlet(foo)
    bar_greenlet = Greenlet(bar)

    foo_greenlet.start()
    bar_greenlet.start()

    print(threading.enumerate())
    gevent.joinall([foo_greenlet, bar_greenlet])
