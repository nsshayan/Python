import gevent
import threading
from random import randint

def foo(name, count):
    for i in range(count):
        print("In {}: counting {}".format(name, i))
        gevent.sleep(1)
    print("{}: exiting...".format(name))

if __name__ == '__main__':
    pool = []
    for i in range(10):
        greenlet = gevent.spawn(foo, 
                                "greenlet-{}".format(i), 
                                randint(4, 15))
        pool.append(greenlet)
    print(threading.enumerate())
    gevent.joinall(pool)
    
