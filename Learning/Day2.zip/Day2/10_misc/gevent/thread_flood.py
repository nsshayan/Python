from gevent import monkey
monkey.patch_all()

from itertools import count
from threading import Thread, enumerate
threads = []


def fn():
    from time import sleep
    sleep(60)


for i in count():
    t = Thread(target=fn)
    t.start()
    print("Created thread {}: {}".format(i, t.name))
    threads.append(t)

