from gevent import Greenlet
from gevent import sleep
import gevent

def foo():
    for i in range(10):
        print("foo", i)
        sleep(
def bar():
    for i in range(10):
        print("bar", i)
        sleep(1)

f = Greenlet(foo)
b = Greenlet(bar)

f.start()
b.start()

f.join()
b.join()


