from gevent import monkey; monkey.patch_all()
import gevent

data = list(range(10))

def square(x):
    from time import sleep
    sleep(1)
    data[x] = data[x] ** 2


workers = []
for i in range(10):
    g = gevent.spawn(square, i)
    workers.append(g)

gevent.wait(workers)

print(data)

    

