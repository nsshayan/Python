import gevent
import threading

def foo():
    for i in range(10):
        print("In foo: counting", i)
        gevent.sleep(1)

def bar():
    for i in range(10):
        print("In bar: counting", i)
        gevent.sleep(1)

if __name__ == '__main__':
    foo_greenlet = gevent.spawn(foo)
    bar_greenlet = gevent.spawn(bar)
   
    print(threading.enumerate())
    gevent.joinall([foo_greenlet, bar_greenlet])
    
