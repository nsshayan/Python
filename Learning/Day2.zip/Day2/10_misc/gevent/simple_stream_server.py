from gevent.server import StreamServer

def handle(socket, address):
    socket.send(b"Hello from a telnet!\n")
    while True:
        data = socket.recv(20)
        if b"end" in data: break
        socket.send(b"SERVER SAYS: " + data.upper())
    socket.send(b"bye!")
    socket.close()

server = StreamServer(('127.0.0.1', 5000), handle)
server.serve_forever()
