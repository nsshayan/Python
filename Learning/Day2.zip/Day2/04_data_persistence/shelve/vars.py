name = "Sam"

count = 10

foo = "Hello world"

print globals()

