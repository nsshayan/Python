from concurrent.futures import ThreadPoolExecutor as Executor
from time import sleep, time

def square(x):
    sleep(2)
    return x*x


if __name__ == '__main__':
    nums = [22, 33, 2, 5, 6, 7]

    start = time()

    #result = list(map(square, nums))

    with Executor(max_workers=10) as workers:
        result = workers.map(square, nums)

    duration = time() - start
    print(f"map() took {duration} seconds")
    print("result = ", list(result))


    #print(result)
