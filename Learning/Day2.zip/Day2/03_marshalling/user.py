class User:
    def __init__(self, name, role, dept):
        self.name, self.role, self.dept = name, role, dept
        print(f"Create a user object - {self.name}")

    def __str__(self):
        return f"User {self.name}, role: {self.role}, dept: {self.dept}"

    def greet(self):
        print(f"{self.name.capitalize()} says 'Hello'")
