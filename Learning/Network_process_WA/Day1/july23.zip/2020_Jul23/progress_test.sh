#!/bin/sh
for i in $(seq 10)
do
    printf "%2d " $i
    sleep 1
done

