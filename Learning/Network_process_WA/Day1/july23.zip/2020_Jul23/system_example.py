import os

ret = os.system("ifconfig")
print(ret)