#!/bin/sh

i=0
while true
do
    echo "Counting $((i++))"
done
