#!/usr/bin/env python
from time import sleep

for i in range(10):
    print("testscript.py counting:", i)
    sleep(1)

