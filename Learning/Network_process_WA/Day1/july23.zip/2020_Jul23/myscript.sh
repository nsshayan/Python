#!/bin/sh
echo "This is a test script" >> myscript.out

