#!/bin/sh
while true
do
    echo "Running $(date)"
done

