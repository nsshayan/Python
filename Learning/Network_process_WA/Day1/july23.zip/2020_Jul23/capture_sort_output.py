from subprocess import Popen, PIPE

with Popen("sort", stdin=PIPE)