from subprocess import Popen
from time import sleep

print("Running ls command...")
child_process = Popen(["ls", "-lR"("ls command running: ", child_process)
sleep(5)

child_process.kill()
print("ls command killed...")