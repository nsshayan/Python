from subprocess import Popen

p = Popen("ls")
print("Launched ls command: p =", p)
