#!/bin/bash

I=0
while true
do
   echo "Scripting counting: $I"
   I=$((I+1))
   sleep 1
done

