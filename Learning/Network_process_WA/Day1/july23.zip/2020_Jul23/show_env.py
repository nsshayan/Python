#!/usr/bin/env python

import os
print(os.environ)

