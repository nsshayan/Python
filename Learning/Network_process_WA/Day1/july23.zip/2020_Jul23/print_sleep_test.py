#!/usr/local/bin/python3
from time import sleep

for i in range(10):
    print(".", end="")
    sleep(1)

print("done.")
