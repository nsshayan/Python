#!/bin/sh
for i in {1..10}
do
	echo "$0: counting $i"
	sleep 1
done
