import os

print("Running ls command...")
ret = os.system("ls")
print("ls command complete: ", ret)