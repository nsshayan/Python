#!/usr/bin/env python
a = input("Enter first value: ")
print(f"The value for a = {a}")
b = input("Enter second value: ")
print(f"The value for b = {b}")
c = a + b
print(f"The sum of {a} and {b} is {c}")

