import subprocess

ret = subprocess.run("ls")
print(ret)

