#!/usr/bin/env python3
from time import sleep

for i in range(10):
    print("{:02d}".format(i), end=" ")
    sleep(0.5)
