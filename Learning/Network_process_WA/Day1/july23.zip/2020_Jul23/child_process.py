#!/usr/bin/env python

import os
for k, v in os.environ.items():
    print("{} = {}".format(k, v))


