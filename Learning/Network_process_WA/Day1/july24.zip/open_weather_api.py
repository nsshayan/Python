# OpenWeather API
forecast_url = "http://api.openweathermap.org/data/2.5/forecast?id={STATION_ID}&APPID={APIKEY}"

weather_url = "http://api.openweathermap.org/data/2.5/weather?q={CITY}&APPID={APIKEY}"

api_key = "932c152d6ff8d185bfdd9d2a5f8e33e4"
bengaluru = "1277333"
chennai = "1264527"
delhi = "1273294"
