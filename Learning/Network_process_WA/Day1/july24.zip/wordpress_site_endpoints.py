home_url = "http://testing.chandrashekar.info/"

username = "testuser"
password = "w3lc0me"

login_url = "http://testing.chandrashekar.info/wp-login.php"

logged_in_url = "http://testing.chandrashekar.info/wp-admin/"

add_new_post_url = "http://testing.chandrashekar.info/wp-admin/post-new.php"
