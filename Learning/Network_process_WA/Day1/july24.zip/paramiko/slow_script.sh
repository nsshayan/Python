#!/bin/sh
COUNT=0
while true
do
   echo "Counting $((COUNT++))"
   sleep 1
done

