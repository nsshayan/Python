# -*- coding: utf-8 -*-
import scrapy


class TestQuoteSpider(scrapy.Spider):
    name = 'test_quote_spider'
    allowed_domains = ['quotes.toscrape.com']
    start_urls = ['http://quotes.toscrape.com/']

    def parse(self, response):
        pass
