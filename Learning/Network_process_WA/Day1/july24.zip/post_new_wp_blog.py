LOGIN_URL = "http://testing.chandrashekar.info/wp-login"
ADMIN_USERNAME = "pythonista"
ADMIN_PASSWORD = "w3lc0me"

ADMIN_URL = "http://testing.chandrashekar.info/wp-admin/"
NEW_POST_URL = "http://testing.chandrashekar.info/wp-admin/post-new.php"

POST_SUCCESS_URL = "http://testing.chandrashekar.info/wp-admin/post.php?post=9&action=edit&message=6"
