import lxml.html as hp

html = hp.parse("https://www.chandrashekar.info/")
print(html)

